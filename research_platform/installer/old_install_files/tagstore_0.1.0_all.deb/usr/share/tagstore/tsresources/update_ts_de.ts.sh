#!/bin/sh
## after modifying »ts_de.ts« you need to update:
lrelease -verbose tagstore.pro

#end
